# TNSDC-GENERATIVE-AI

dataset link : https://www.kaggle.com/datasets/wenewone/cub2002011
